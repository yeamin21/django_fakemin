from django.apps import AppConfig


class FakeminConfig(AppConfig):
    name = "fakemin"
    verbose_name = "FakeMin"